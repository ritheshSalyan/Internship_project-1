# Hello developers :clap:

  
  

### Instruction on forking

1. Fork this repository on to your profile

2. Clone the repository from your profile to your PC

3. Open the terminal in your PC and follow the command

 
```` terminal

git remote add upstream https://github.com/imcoffeefreak/Internship_project.git

  

````

4. Now check your your remote origins

  

```` terminal

  

git remote -v

  

````

5. Hence forth when ever you want to push just push it on to your origin and then send me the merge request through GitHub

7. When ever I update it! its wise to always do 

```` terminal 
git pull upstream master
````


			
Made with :heart: open-source
